﻿using DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repos
{
    public class UserRepo
    {
        static WalletDbContext db;
        static UserRepo()
        {
            db = new WalletDbContext();
        }
        public static List<User> Get()
        {
            return db.Users.ToList();
        }
        public static User Get(int id)
        {
            return db.Users.Find(id);
        }
        public static bool Create(User obj)
        {
            db.Users.Add(obj);
            return db.SaveChanges() > 0;
        }
        public static bool Update(User obj)
        {
            var ex = db.Users.Find(obj.Id);
            db.Entry(ex).CurrentValues.SetValues(obj);
            return db.SaveChanges() > 0;

        }
        static public bool Delete(int id)
        {
            var ex = db.Users.Find(id);
            db.Users.Remove(ex);
            return db.SaveChanges() > 0;
        }
        
    }
}
